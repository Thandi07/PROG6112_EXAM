/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mattresssales;
import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author thand
 */
public class ProductApp extends JFrame {
 
    // Declaring the GUI components
    private JTextField txtCustomerName;
    private JTextField txtProductPrice;

    private JComboBox<String> cmbProduct;

    private JLabel lblVAT;
    private JLabel lblCommission;
    private JLabel lblTotal;

    // Constructor for application window
    public ProductApp() {

        setTitle("Mattress Sales Application");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create the main panel
        JPanel panel = new JPanel(new GridLayout(8, 2, 10, 10));

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();

        // Create File menu
        JMenu fileMenu = new JMenu("File");

        // Create Exit menu item
        JMenuItem exitItem = new JMenuItem("Exit");

        // Exit closes the application
        exitItem.addActionListener(e -> System.exit(0));

        fileMenu.add(exitItem);

        // Create Tools menu
        JMenu toolsMenu = new JMenu("Tools");

        // Create Process and Clear menu items
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");

        // Connect menu items to their methods
        processItem.addActionListener(e -> processSale());
        clearItem.addActionListener(e -> clearFields());

        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        // Add menus to menu bar
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        // Customer name text field
        panel.add(new JLabel("Customer Name:"));
        txtCustomerName = new JTextField();
        panel.add(txtCustomerName);

        // Product selection combo box
        panel.add(new JLabel("Select Product:"));

        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        cmbProduct = new JComboBox<>(products);
        panel.add(cmbProduct);

        // Product price text field
        panel.add(new JLabel("Enter Price:"));
        txtProductPrice = new JTextField();
        panel.add(txtProductPrice);

        // Display VAT
        panel.add(new JLabel("VAT Amount:"));
        lblVAT = new JLabel("R0.00");
        panel.add(lblVAT);

        // Display commission
        panel.add(new JLabel("Commission Amount:"));
        lblCommission = new JLabel("R0.00");
        panel.add(lblCommission);

        // Display total sale
        panel.add(new JLabel("Total Sale Amount:"));
        lblTotal = new JLabel("R0.00");
        panel.add(lblTotal);

        // Create Process button
        JButton btnProcess = new JButton("PROCESS");

        // Create Clear button
        JButton btnClear = new JButton("CLEAR");

        // Connect buttons to their methods
        btnProcess.addActionListener(e -> processSale());
        btnClear.addActionListener(e -> clearFields());

        panel.add(btnProcess);
        panel.add(btnClear);

        // Add panel to the window
        add(panel);

        setVisible(true);
    }

    // Method to process the mattress sale
    private void processSale() {

        try {

            // Capture customer name
            String customerName =
                    txtCustomerName.getText().trim();

            // Capture selected product
            String productName =
                    cmbProduct.getSelectedItem().toString();

            // Capture product price
            double price =
                    Double.parseDouble(txtProductPrice.getText());

            // Validate customer name and price
            if (customerName.isEmpty() || price <= 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "Enter a customer name and a valid price."
                );
                return;
            }

            // Create ProductCalculations object
            ProductCalculations calculation =
                    new ProductCalculations(price);

            // Calculate VAT, commission and total
            double vat = calculation.GetVat();
            double commission = calculation.GetCommission();
            double total = calculation.GetTotal();

            lblVAT.setText(String.format("R%.2f", vat));

            lblCommission.setText(
                    String.format("R%.2f", commission));

            lblTotal.setText(
                    String.format("R%.2f", total));

            // Save the sale information to data.txt
            saveToFile(customerName, productName,
                    vat, commission, total);

            // Display confirmation message
            JOptionPane.showMessageDialog(
                    this,
                    "Customer Name: " + customerName
                    + "\nProduct: " + productName
                    + "\nVAT: R" + String.format("%.2f", vat)
                    + "\nCommission: R"
                    + String.format("%.2f", commission)
                    + "\nTotal: R" + String.format("%.2f", total)
            );

        } catch (NumberFormatException e) {

            // Handle invalid price input
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid numeric price."
            );

        } catch (IOException e) {

            // Handle file saving errors
            JOptionPane.showMessageDialog(
                    this,
                    "Error saving information to file."
            );
        }
    }

    // Method to save sales information to data.txt
    private void saveToFile(String customerName,
            String productName, double vat,
            double commission, double total)
            throws IOException {

        // Append the new sale to the file
        FileWriter writer = new FileWriter("data.txt", true);

        writer.write("DATA LOG\n");
        writer.write("Customer Name: " + customerName + "\n");
        writer.write("Product: " + productName + "\n");
        writer.write("VAT: R" + String.format("%.2f", vat) + "\n");
        writer.write("COMMISSION: R"
                + String.format("%.2f", commission) + "\n");
        writer.write("TOTAL: R"
                + String.format("%.2f", total) + "\n");
        writer.write("************************\n");

        // Close the file
        writer.close();
    }

    // Method to clear all input and output fields
    private void clearFields() {

        txtCustomerName.setText("");
        txtProductPrice.setText("");

        // Set the combo box to its first item
        cmbProduct.setSelectedIndex(0);

        // Reset calculated amounts
        lblVAT.setText("R0.00");
        lblCommission.setText("R0.00");
        lblTotal.setText("R0.00");
    }

    // Main method starts the application
    public static void main(String[] args) {

        // Run the GUI application
        SwingUtilities.invokeLater(() -> {
            new ProductApp();
        });
    }
}
