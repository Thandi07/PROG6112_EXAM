/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package mattresssales;

/**
 *
 * @author thand
 */
public interface IProductCalculations {

    // calculate VAT
    double GetVat();

    // calculate commission
    double GetCommission();

    // calculate total sale amount
    double GetTotal();
}