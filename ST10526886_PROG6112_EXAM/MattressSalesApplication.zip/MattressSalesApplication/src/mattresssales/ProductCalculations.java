/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mattresssales;

/**
 *
 * @author thand
 */
public class ProductCalculations implements IProductCalculations {

    // Store the price of the mattress
    private double productPrice;

    // Constructor 
    public ProductCalculations(double productPrice) {
        this.productPrice = productPrice;
    }

    // Calculate 15% VAT
    @Override
    public double GetVat() {
        return productPrice * 0.15;
    }

    // Calculate 5% commission
    @Override
    public double GetCommission() {
        return productPrice * 0.05;
    }

    // Calculate total sale amount
    @Override
    public double GetTotal() {
        return productPrice + GetVat() + GetCommission();
    }
}