/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import mattresssales.ProductCalculations;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author thand
 */
public class ProductCalculationsTest {

    // Test whether VAT is calculated correctly
    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {

        // Create an object with a price of R3500
        ProductCalculations calculation =
                new ProductCalculations(3500);

        // Expected VAT is R525
        double expected = 525.00;

        // Get the actual VAT amount
        double actual = calculation.GetVat();

        // Compare expected and actual results
        assertEquals(expected, actual, 0.01);
    }

    // Test whether total sale is calculated correctly
    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {

        // Create an object with a price of R3500
        ProductCalculations calculation =
                new ProductCalculations(3500);

        // Expected total is R4200
        double expected = 4200.00;

        // Get the actual total sale amount
        double actual = calculation.GetTotal();

        // Compare expected and actual results
        assertEquals(expected, actual, 0.01);
    }
}