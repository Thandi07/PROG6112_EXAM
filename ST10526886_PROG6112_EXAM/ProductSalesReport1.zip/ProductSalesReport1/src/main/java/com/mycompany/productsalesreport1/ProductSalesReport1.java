/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productsalesreport1;
import java.util.Scanner;
/**
 *
 * @author thand
 */


// Main class that runs the application
public class ProductSalesReport1 {

    public static void main(String[] args) {

        // Create a Scanner object to receive user input
        Scanner input = new Scanner(System.in);

        // One-dimensional array containing the product names
        String[] productNames = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        // Two-dimensional array to store monthly sales
        int[][] monthlySales = new int[3][3];

        // Loop through each product
        for (int i = 0; i < productNames.length; i++) {

            // Loop through the three months
            for (int j = 0; j < 3; j++) {

                System.out.print(
                    "Enter number of sales for month "
                    + (j + 1) + " for "
                    + productNames[i] + " mattress: "
                );

                // Store the user's input in the array
                monthlySales[i][j] = input.nextInt();
            }

            // Add a blank line after each product
            System.out.println();
        }

        // Create a Product object and pass the arrays
        Product product = new Product(productNames, monthlySales);

        // Create a PrintProduct object
        PrintProduct printer = new PrintProduct();

        // Display the completed sales report
        printer.PrintReport(product);

        // Close the Scanner
        input.close();
    }
}