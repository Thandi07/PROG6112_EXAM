/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.productsalesreport1;

/**
 *
 * @author thand
 */
public interface IProduct {

    // Returnd the total products sold in number
    int GetTotalProductsSold();

    // gets avarage products sold
    double GetAverageProductSold();

    // Gets most popular products
    String GetMostPopularProduct();

}