/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.productsalesreport1;

/**
 *
 * @author thand
 */
public class Product implements IProduct {

    // One-dimensional array 
    private String[] productNames;

    // Two-dimensional array 
    private int[][] monthlySales;

    // Constructor 
    public Product(String[] productNames, int[][] monthlySales) {

        this.productNames = productNames;
        this.monthlySales = monthlySales;
    }

    // override method
    @Override
    public int GetTotalProductsSold() {

        int total = 0;

        // Loop through each product
        for (int i = 0; i < monthlySales.length; i++) {

            // Loop through the three months
            for (int j = 0; j < monthlySales[i].length; j++) {

                total += monthlySales[i][j];
            }
        }

        return total;
    }

    // override method
    @Override
    public double GetAverageProductSold() {

        int total = GetTotalProductsSold();

        // Calculate the number of monthly sales entries
        int numberOfSales = monthlySales.length
                * monthlySales[0].length;

        // Return the average
        return (double) total / numberOfSales;
    }

    // override method
    @Override
    public String GetMostPopularProduct() {

        int highestSales = 0;
        String popularProduct = "";

        // Loop through each product
        for (int i = 0; i < monthlySales.length; i++) {

            int productTotal = 0;

            // Calculate the total sales for this product
            for (int j = 0; j < monthlySales[i].length; j++) {

                productTotal += monthlySales[i][j];
            }

            // Check whether this product has the highest sales
            if (productTotal > highestSales) {

                highestSales = productTotal;
                popularProduct = productNames[i];
            }
        }

        return popularProduct;
    }

}
