/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.productsalesreport1;

/**
 *
 * @author thand
 */
public class PrintProduct {

    
    public void PrintTotalSales(Product product) {

        System.out.println("TOTAL PRODUCT SALES: "
                + product.GetTotalProductsSold());
    }

    // print average
    public void PrintAverageSales(Product product) {

        System.out.println("AVERAGE PRODUCT SALES: "
                + product.GetAverageProductSold());
    }

    // print most popular
    public void PrintMostPopularProduct(Product product) {

        System.out.println("MOST POPULAR PRODUCT: "
                + product.GetMostPopularProduct());
    }

    // display the complete report
    public void PrintReport(Product product) {

        System.out.println();
        System.out.println("PRODUCT SALES REPORT - 2026");

        System.out.println("****************************************");

        // Call printing methods
        PrintTotalSales(product);
        PrintAverageSales(product);
        PrintMostPopularProduct(product);
    }

}