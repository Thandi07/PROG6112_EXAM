/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.productsalesreport1.Product;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author thand
 */
public class ProductTest {

    // Unit Test 1:
    // Checks if the total sales calculation is correct
    @Test
    public void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {

        // Arrange: Create test product names
        String[] productNames = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        // Arrange: Create test monthly sales
        int[][] monthlySales = {
            {25, 18, 20},
            {15, 10, 12},
            {18, 15, 20}
        };

        // Create a Product object
        Product product = new Product(productNames, monthlySales);

        // Act: Call the total sales method
        int result = product.GetTotalProductsSold();

        // Assert: Check whether the result is 153
        assertEquals(153, result);
    }

    // Unit Test 2:
    // Checks if the average sales calculation is correct
    @Test
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {

        // Arrange: Create test product names
        String[] productNames = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        // Arrange: Create test monthly sales
        int[][] monthlySales = {
            {25, 18, 20},
            {15, 10, 12},
            {18, 15, 20}
        };

        // Create a Product object
        Product product = new Product(productNames, monthlySales);

        // Act: Call the average sales method
        double result = product.GetAverageProductSold();

        // Assert: Check whether the result is 17
        assertEquals(17.0, result, 0.001);
    }

}